package guia08_ejercicio06;

import Servicios.ServiciosProducto;

public class Guia08_Ejercicio06 {

    public static void main(String[] args) {
        /*
        creamos instancia con la que trabajaremos
         */
        ServiciosProducto servProducto = new ServiciosProducto();

        /*
        abajo el código para ejecutar
         */
        boolean menu = servProducto.menuTienda();

    }

}
