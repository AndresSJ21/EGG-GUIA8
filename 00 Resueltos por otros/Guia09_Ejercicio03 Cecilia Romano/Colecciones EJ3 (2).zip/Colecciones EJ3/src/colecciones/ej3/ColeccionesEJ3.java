
package colecciones.ej3;

import Service.servicioAlumno;

public class ColeccionesEJ3 {

    
    public static void main(String[] args) {
     
        servicioAlumno A1=new servicioAlumno();
        
        A1.fabicAlumno();
        A1.mostrarAlumnos();
        
        A1.buscarCalcular();
        A1.mostrarAlumnos();
    }
    
}
